package edu.uob;

public class GameAction
{
}
